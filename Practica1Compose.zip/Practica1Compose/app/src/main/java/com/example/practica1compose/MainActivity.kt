package com.example.practica1compose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PantallaColores()
        }
    }
}

@Composable
fun PantallaColores() {

    Column(modifier = Modifier.fillMaxSize()) {
        //Espacio entre filas
        Spacer(modifier= Modifier.run { height(8.dp) })

        // ===== FILA SUPERIOR =====
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .fillMaxHeight()
        ) {

            ColorBox("Rojo", Color.Red, Modifier.weight(1f).fillMaxHeight())
            ColorBox("Azul", Color.Blue, Modifier.weight(1f).fillMaxHeight())
            ColorBox("Verde", Color.Green, Modifier.weight(1f).fillMaxHeight())
            ColorBox("Amarillo", Color.Yellow, Modifier.weight(1f).fillMaxHeight())
        }

        //Espacio entre filas
        Spacer(modifier= Modifier.run { height(8.dp) })

        // ===== COLUMNA INFERIOR =====
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {

            ColorBox("Rojo", Color.Red, Modifier.weight(1f))
            ColorBox("Azul", Color.Blue, Modifier.weight(1f))
            ColorBox("Verde", Color.Green, Modifier.weight(1f))
            ColorBox("Amarillo", Color.Yellow, Modifier.weight(1f))
        }
    }
}

@Composable
fun ColorBox(texto: String, color: Color, modifier: Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = texto,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewPantalla() {
    PantallaColores()
}